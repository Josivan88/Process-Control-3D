
#ifndef _W5100LWIP_H
#define _W5100LWIP_H

#include <LwipIntfDev.h>
#include <utility/w5100.h>

using Wiznet5100lwIP = LwipIntfDev<Wiznet5100>;

#endif // _W5500LWIP_H
